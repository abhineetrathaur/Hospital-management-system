﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace HMS
{
    public partial class LoginMaster : Form
    {
        SqlConnection cn;
        public LoginMaster()
        {
            InitializeComponent();
            cn = new SqlConnection();
            cn.ConnectionString = "Data Source=.;Initial Catalog=HMS;Integrated Security=True";
        }

        private void LoginMaster_Load(object sender, EventArgs e)
        {
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlDataAdapter da = new SqlDataAdapter("select * from Login where Username='"+txtusername.Text+"' and password='"+txtpassword.Text+"'",cn);
            DataSet ds = new DataSet();
            ds.Clear();
            da.Fill(ds, "Login");
            if (ds.Tables[0].Rows.Count > 0)
            {
                MDI ob = new MDI();
                ob.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Invalid");
            }
        }
    }
}
