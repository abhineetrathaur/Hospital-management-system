﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace HMS
{
    public partial class Staff : Form
    {
        SqlConnection cn;
        int flag;
        int sID;
        public Staff()
        {
            InitializeComponent();
            cn = new SqlConnection();
            cn.ConnectionString = "Data Source=.;Initial Catalog=HMS;Integrated Security=True"; 
        }

        private void Staff_Load(object sender, EventArgs e)
        {
            getData();
            btnsave.Enabled = false;
            disable();
        }
        public void getData()
        {
            SqlDataAdapter da = new SqlDataAdapter("select * from Staff", cn);
            DataSet ds = new DataSet();
            ds.Clear();
            da.Fill(ds, "Staff");
            dgstaff.DataSource = ds.Tables[0];
        }
        public void disable()
        {
            txtsname.ReadOnly = true;
            txtage.ReadOnly = true;
            txtgender.ReadOnly = true;
            txtaddress.ReadOnly = true;
            txtwork.ReadOnly = true;
            txtphoneno.ReadOnly = true;

        }
        public void enable()
        {
            txtsname.ReadOnly = false;
            txtage.ReadOnly = false;
            txtgender.ReadOnly = false;
            txtaddress.ReadOnly = false;
            txtwork.ReadOnly = false;
            txtphoneno.ReadOnly = false;
        }

        private void btninsert_Click(object sender, EventArgs e)
        {
            flag = 0;
            enable();
            btnsave.Enabled = true;
            txtsname.Focus();
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            flag = 1;
            enable();
            btnsave.Enabled = true;
            txtsname.Focus();
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cn;
            cmd.CommandType = CommandType.Text;
            if (flag == 0)
            {
                cmd.CommandText = "insert into Staff values(@Sname,@Age,@Gender,@Address,@Work,@Phone)";
            }
            if (flag == 1)
            {
                cmd.CommandText = "update Staff set Sname=@Sname,Age=@Age,Gender=@Gender,Saddress=@Address,Work=@Work,Phoneno=@Phone where sID=@sID";
                cmd.Parameters.AddWithValue("@DoctorID", sID);
            }
            cmd.Parameters.AddWithValue("@Sname", txtsname.Text);
            cmd.Parameters.AddWithValue("@Age", txtage.Text);
            cmd.Parameters.AddWithValue("@Gender", txtgender.Text);
            cmd.Parameters.AddWithValue("@Address", txtaddress.Text);
            cmd.Parameters.AddWithValue("@Work", txtwork.Text);
            cmd.Parameters.AddWithValue("@Phone", txtphoneno.Text);

            cn.Open();
            cmd.ExecuteNonQuery();
            cn.Close();
            MessageBox.Show("Record Saved");
            getData();
            btnsave.Enabled = false;
            clr();
            getData();
        }

        public void clr()
        {
            txtsname.Clear();
            txtage.Clear();
            txtgender.Clear();
            txtaddress.Clear();
            txtwork.Clear();
            txtphoneno.Clear();
        }

        private void Staff_KeyDown(object sender, KeyEventArgs e)
        {
            int i = dgstaff.CurrentRow.Index;
            sID = int.Parse(dgstaff.Rows[i].Cells[0].Value.ToString());
            record(sID);
        }

        private void Staff_KeyUp(object sender, KeyEventArgs e)
        {

            int i = dgstaff.CurrentRow.Index;
            sID = int.Parse(dgstaff.Rows[i].Cells[0].Value.ToString());
            record(sID);
        }
        public void record(int Cno)
        {
            SqlDataAdapter da = new SqlDataAdapter("select * from Staff where Stid=" + sID, cn);
            DataSet ds = new DataSet();
            ds.Clear();
            da.Fill(ds, "Staff");
            txtsname.Text = ds.Tables[0].Rows[0][1].ToString();
            txtage.Text = ds.Tables[0].Rows[0][2].ToString();
            txtgender.Text = ds.Tables[0].Rows[0][3].ToString();
            txtaddress.Text = ds.Tables[0].Rows[0][4].ToString();
            txtwork.Text = ds.Tables[0].Rows[0][5].ToString();
            txtphoneno.Text = ds.Tables[0].Rows[0][6].ToString();
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
             SqlCommand cmd = new SqlCommand();
            cmd.Connection = cn;
            cmd.CommandType = CommandType.Text;

            cmd.CommandText = "delete from staff where sID=@sID";
            cmd.Parameters.AddWithValue("@sID", sID);

            cn.Open();
            cmd.ExecuteNonQuery();
            cn.Close();
            MessageBox.Show("Record Deleted");
            disable();
            btnsave.Enabled = false;
            clr();
            getData();
        }

        private void dgstaff_KeyDown(object sender, KeyEventArgs e)
        {
            int i = dgstaff.CurrentRow.Index;
            sID = int.Parse(dgstaff.Rows[i].Cells[0].Value.ToString());
            record(sID);
        }

        private void dgstaff_KeyUp(object sender, KeyEventArgs e)
        {
            int i = dgstaff.CurrentRow.Index;
            sID = int.Parse(dgstaff.Rows[i].Cells[0].Value.ToString());
            record(sID);
        }



    }
}
