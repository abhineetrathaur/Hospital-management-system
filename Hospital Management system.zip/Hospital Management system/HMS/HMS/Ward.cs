﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace HMS
{
    public partial class Ward : Form
    {
        SqlConnection cn;
        int flag;
        int wID;
        public Ward()
        {
            InitializeComponent();
            cn = new SqlConnection();
            cn.ConnectionString = "Data Source=.;Initial Catalog=HMS;Integrated Security=True";
        }

        private void Ward_Load(object sender, EventArgs e)
        {
            getData();
            btnsave.Enabled = false;
            disable();
        }
        public void getData()
        {
            SqlDataAdapter da = new SqlDataAdapter("select * from Ward", cn);
            DataSet ds = new DataSet();
            ds.Clear();
            da.Fill(ds, "Ward");
            dgward.DataSource = ds.Tables[0];
        }
        public void disable()
        {
            txtwno.ReadOnly = true;
            txtwname.ReadOnly = true;
            txtwfloor.ReadOnly = true;
            

        }
        public void enable()
        {
            txtwno.ReadOnly = false;
            txtwname.ReadOnly = false;
            txtwfloor.ReadOnly = false;
        }

        private void btninsert_Click(object sender, EventArgs e)
        {

            flag = 0;
            enable();
            btnsave.Enabled = true;
            txtwno.Focus();
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {

            flag = 1;
            enable();
            btnsave.Enabled = true;
            txtwno.Focus();
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cn;
            cmd.CommandType = CommandType.Text;
            if (flag == 0)
            {
                cmd.CommandText = "insert into Ward values(@wno,@wname,@wfloor)";
            }
            if (flag == 1)
            {
                cmd.CommandText = "update Ward set Wno=@wno,Wname=@wname,Wfloor=@wfloor where wID=@wID";
                cmd.Parameters.AddWithValue("@wID", wID);
            }
            cmd.Parameters.AddWithValue("@wno", txtwno.Text);
            cmd.Parameters.AddWithValue("@wname", txtwname.Text);
            cmd.Parameters.AddWithValue("@wfloor", txtwfloor.Text);
           

            cn.Open();
            cmd.ExecuteNonQuery();
            cn.Close();
            MessageBox.Show("Record Saved");
            disable();
            btnsave.Enabled = false;
            clr();
            getData();
        }
        public void clr()
        {
            txtwno.Clear();
            txtwname.Clear();
            txtwfloor.Clear();
        }

        
        public void record(int Cno)
        {
            SqlDataAdapter da = new SqlDataAdapter("select * from Ward where wID=" + wID, cn);
            DataSet ds = new DataSet();
            ds.Clear();
            da.Fill(ds, "Ward");
            txtwno.Text = ds.Tables[0].Rows[0][1].ToString();
            txtwname.Text = ds.Tables[0].Rows[0][2].ToString();
            txtwfloor.Text = ds.Tables[0].Rows[0][3].ToString();
            

        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cn;
            cmd.CommandType = CommandType.Text;

            cmd.CommandText = "delete from Ward where wID=@wID";
            cmd.Parameters.AddWithValue("@DoctorID", wID);

            cn.Open();
            cmd.ExecuteNonQuery();
            cn.Close();
            MessageBox.Show("Record Deleted");
            disable();
            btnsave.Enabled = false;
            clr();
            getData();
        }

       

        private void dgward_KeyDown(object sender, KeyEventArgs e)
        {
            int i = dgward.CurrentRow.Index;
            wID = int.Parse(dgward.Rows[i].Cells[0].Value.ToString());
            record(wID);
        }

        private void dgward_KeyUp(object sender, KeyEventArgs e)
        {
            int i = dgward.CurrentRow.Index;
            wID = int.Parse(dgward.Rows[i].Cells[0].Value.ToString());
            record(wID);
        }





    }
}
