﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HMS
{
    public partial class MDI : Form
    {
        public MDI()
        {
            InitializeComponent();
        }

        private void MDI_Load(object sender, EventArgs e)
        {

        }

        private void doctorToolStripMenuItem_Click(object sender, EventArgs e)
        {
           Doctor doc=new Doctor();
            doc.MdiParent=this;
            doc.Show();

        }

        private void patientToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Patient pa=new Patient();
            pa.MdiParent=this;
            pa.Show();
        }

        private void staffToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Staff sa = new Staff();
            sa.MdiParent = this;
            sa.Show();

        }

        private void wardToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Ward w = new Ward();
            w.MdiParent = this;
            w.Show();
        }

        private void billToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Bill b = new Bill();
            b.MdiParent = this;
            b.Show();
        }

        private void calculatorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("calc.exe");
        }

        private void notepadToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("Notepad.exe");
        }
    }
}
