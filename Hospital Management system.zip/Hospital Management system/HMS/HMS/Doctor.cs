﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace HMS
{
    public partial class Doctor : Form
    {
        SqlConnection cn;
        int flag;
        int DoctorID;
        public Doctor()
        {
            InitializeComponent();
            cn = new SqlConnection();
            cn.ConnectionString = "Data Source=.;Initial Catalog=HMS;Integrated Security=True";
        }

        private void Doctor_Load(object sender, EventArgs e)
        {
            getData();
            btnsave.Enabled = false;
            disable();
        }
        public void getData()
        {
            SqlDataAdapter da = new SqlDataAdapter("select * from Doctor", cn);
            DataSet ds = new DataSet();
            ds.Clear();
            da.Fill(ds, "Doctor");
            dgdoctor.DataSource = ds.Tables[0];
        }
        public void disable()
        {
            txtdegree.ReadOnly = true;
            txtcity.ReadOnly = true;
            txtname.ReadOnly = true;
            txtphone.ReadOnly = true;
           
        }
        public void enable()
        {
            txtdegree.ReadOnly = false;
            txtcity.ReadOnly = false;
            txtname.ReadOnly = false;
            txtphone.ReadOnly = false;
        }

        private void btninsert_Click(object sender, EventArgs e)
        {
            flag = 0;
            enable();
            btnsave.Enabled = true;
            txtname.Focus();
        }

        private void btnupdate_Click(object sender, EventArgs e)
        {
            flag = 1;
            enable();
            btnsave.Enabled = true;
            txtname.Focus();
        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cn;
            cmd.CommandType = CommandType.Text;
            if (flag == 0)
            {
                cmd.CommandText = "insert into Doctor values(@Dname,@Degree,@Contact,@City)";
            }
            if (flag == 1)
            {
                cmd.CommandText = "update Doctor set Name=@Dname,Degree=@Degree,Phone=@Contact,City=@City where DoctorID=@DoctorID";
                cmd.Parameters.AddWithValue("@DoctorID", DoctorID);
            }
            cmd.Parameters.AddWithValue("@Dname", txtname.Text);
            cmd.Parameters.AddWithValue("@Degree", txtdegree.Text);
            cmd.Parameters.AddWithValue("@Contact", txtphone.Text);
            cmd.Parameters.AddWithValue("@City", txtcity.Text);
            
            cn.Open();
            cmd.ExecuteNonQuery();
            cn.Close();
            MessageBox.Show("Record Saved");
            disable();
            btnsave.Enabled = false;
            clr();
            getData();
        }
        public void clr()
        {
            txtphone.Clear();
            txtname.Clear();
            txtcity.Clear();
            txtcity.Clear();
            txtdegree.Clear();
        }

        private void dgdoctor_KeyDown(object sender, KeyEventArgs e)
        {
            int i = dgdoctor.CurrentRow.Index;
            DoctorID = int.Parse(dgdoctor.Rows[i].Cells[0].Value.ToString());
            record(DoctorID);
        }

        private void dgdoctor_KeyUp(object sender, KeyEventArgs e)
        {
            int i = dgdoctor.CurrentRow.Index;
            DoctorID = int.Parse(dgdoctor.Rows[i].Cells[0].Value.ToString());
            record(DoctorID);
        }
        public void record(int Cno)
        {
            SqlDataAdapter da = new SqlDataAdapter("select * from Doctor where DoctorID=" + DoctorID, cn);
            DataSet ds = new DataSet();
            ds.Clear();
            da.Fill(ds, "Doctor");
            txtname.Text = ds.Tables[0].Rows[0][1].ToString();
            txtdegree.Text = ds.Tables[0].Rows[0][2].ToString();
            txtphone.Text = ds.Tables[0].Rows[0][3].ToString();
            txtcity.Text = ds.Tables[0].Rows[0][4].ToString();
            
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = cn;
            cmd.CommandType = CommandType.Text;

            cmd.CommandText = "delete from Doctor where DoctorID=@DoctorID";
            cmd.Parameters.AddWithValue("@DoctorID", DoctorID);

            cn.Open();
            cmd.ExecuteNonQuery();
            cn.Close();
            MessageBox.Show("Record Deleted");
            disable();
            btnsave.Enabled = false;
            clr();
            getData();
        }

    }
}
