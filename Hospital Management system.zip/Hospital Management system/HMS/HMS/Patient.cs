﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace HMS
{
    public partial class Patient : Form
    {
        SqlConnection cn;
        int flag;
        int pid;
        public Patient()
        {
            InitializeComponent();
             cn = new SqlConnection();
             cn.ConnectionString = "Data Source=.;Initial Catalog=HMS;Integrated Security=True";
        }

        private void txtphone_TextChanged(object sender, EventArgs e)
        {

        }

        private void Patient_Load(object sender, EventArgs e)
        {
            getData();
            btnsave.Enabled = false;
            disable();
        }
          public void getData()
        {
            SqlDataAdapter da = new SqlDataAdapter("select * from Patient", cn);
            DataSet ds = new DataSet();
            ds.Clear();
            da.Fill(ds, "Patient");
            dgpatient.DataSource = ds.Tables[0];
        }
          public void disable()
          {
              txtpname.ReadOnly = true;
              txtaddress.ReadOnly = true;
              txtphoneno.ReadOnly = true;
              txtage.ReadOnly = true;
              txtgender.ReadOnly = true;
          }
          public void enable()
          {
              txtpname.ReadOnly = false;
              txtaddress.ReadOnly = false;
              txtphoneno.ReadOnly = false;
              txtage.ReadOnly = false;
              txtgender.ReadOnly = false;
          }

          private void btninsert_Click(object sender, EventArgs e)
          {

              flag = 0;
              enable();
              btnsave.Enabled = true;
              txtpname.Focus();
          }

          private void btnupdate_Click(object sender, EventArgs e)
          {

              flag = 1;
              enable();
              btnsave.Enabled = true;
              txtpname.Focus();
          }

          private void btnsave_Click(object sender, EventArgs e)
          {
              SqlCommand cmd = new SqlCommand();
              cmd.Connection = cn;
              cmd.CommandType = CommandType.Text;
              if (flag == 0)
              {
                  cmd.CommandText = "insert into Patient values(@Pname,@Address,@Phoneno,@Age,@Gender)";
              }
              if (flag == 1)
              {
                  cmd.CommandText = "update Patient set Pname=@Pname,Paddress=@Address,Phoneno=@Phoneno,Age=@Age,Gender=@Gender where pid=@pid";
                  cmd.Parameters.AddWithValue("@pid", pid);
              }
              cmd.Parameters.AddWithValue("@Pname", txtpname.Text);
              cmd.Parameters.AddWithValue("@Address", txtaddress.Text);
              cmd.Parameters.AddWithValue("@Phoneno", txtphoneno.Text);
              cmd.Parameters.AddWithValue("@Age", txtage.Text);
              cmd.Parameters.AddWithValue("@Gender", txtgender.Text);

              cn.Open();
              cmd.ExecuteNonQuery();
              cn.Close();
              MessageBox.Show("Record Saved");
              disable();
              btnsave.Enabled = false;
              clr();
              getData();
          }
          public void clr()
        {
            txtpname.Clear();
            txtaddress.Clear();
            txtphoneno.Clear();
            txtage.Clear();
            txtgender.Clear();
        }

        private void Patient_KeyDown(object sender, KeyEventArgs e)
        {
            int i = dgpatient.CurrentRow.Index;
            pid = int.Parse(dgpatient.Rows[i].Cells[0].Value.ToString());
            record(pid);
        }

        private void Patient_KeyUp(object sender, KeyEventArgs e)
        {
            
    
        }
         public void record(int Cno)
        {
            SqlDataAdapter da = new SqlDataAdapter("select * from Patient where pid=" + pid, cn);
            DataSet ds = new DataSet();
            ds.Clear();
            da.Fill(ds, "Patient");
            txtpname.Text = ds.Tables[0].Rows[0][1].ToString();
            txtaddress.Text = ds.Tables[0].Rows[0][2].ToString();
            txtphoneno.Text = ds.Tables[0].Rows[0][3].ToString();
            txtage.Text = ds.Tables[0].Rows[0][4].ToString();
            txtgender.Text = ds.Tables[0].Rows[0][5].ToString();
        }

         private void btndelete_Click(object sender, EventArgs e)
         {
             SqlCommand cmd = new SqlCommand();
             cmd.Connection = cn;
             cmd.CommandType = CommandType.Text;

             cmd.CommandText = "delete from Patient where pid=@pid";
             cmd.Parameters.AddWithValue("@pid", pid);

             cn.Open();
             cmd.ExecuteNonQuery();
             cn.Close();
             MessageBox.Show("Record Deleted");
             disable();
             btnsave.Enabled = false;
             clr();
             getData();
         }

         private void dgpatient_KeyDown(object sender, KeyEventArgs e)
         {
             int i = dgpatient.CurrentRow.Index;
             pid = int.Parse(dgpatient.Rows[i].Cells[0].Value.ToString());
             record(pid);
         }

         private void dgpatient_KeyUp(object sender, KeyEventArgs e)
         {
             int i = dgpatient.CurrentRow.Index;
             pid = int.Parse(dgpatient.Rows[i].Cells[0].Value.ToString());
             record(pid);
         }

         private void txtpname_TextChanged(object sender, EventArgs e)
         {

         }

         private void txtage_TextChanged(object sender, EventArgs e)
         {

         }

      
         




          

    }
}
