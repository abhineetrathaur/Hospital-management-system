create database HMS
use HMS
create table Login
(
LoginID int primary key identity,
Username varchar(20),
password varchar(20)
)
insert into Login values('admin','admin')
create table Doctor
(
DoctorID int primary key identity,
Name varchar(25),
Degree varchar(20),
Phone varchar(10),
City varchar(20)
)
drop table Patient
drop table Patient
create table Patient
(
Pid int primary key identity,
Pname varchar(max),
Paddress varchar(max),
Phoneno varchar(max),
Age varchar(max),
Gender varchar(max)
)
create table Staff
(
Stid int primary key identity,
Sname varchar(max),
Age varchar(max),
Gender varchar(max),
Saddress varchar(max),
Work varchar(max),
Phoneno varchar(max)
)
drop table Ward
drop table Ward
create table Ward
(
Wid int Primary key identity,
Wno varchar(max),
Wname varchar(max),
Wfloor varchar(max)
)
drop table Bill
create table Bill
(
Bno int primary key identity,
Paname varchar(max),
Doname varchar(max),
Dis varchar(max),
Amt varchar(max)
)